<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.1" name="Decorations" tilewidth="64" tileheight="64" tilecount="42" columns="7">
 <image source="../assets/Decorations (64x64).png" width="448" height="384"/>
</tileset>
